{
    'name': 'Inventory Counting Lists',
    'version': '19.0.1.0.0',
    'category': 'Inventory',
    'summary': 'Department-based daily counting lists for inventory staff',
    'description': """
        Allows managers to create counting lists per department (Kitchen, Bar, Service, etc.)
        Staff open their department list and count assigned products using a mobile-friendly
        numpad interface. Manager reviews counts before applying to inventory.
    """,
    'author': 'Custom',
    'depends': ['stock', 'hr', 'mobile_physical_inventory'],
    'data': [
        'security/ir.model.access.csv',
        'views/counting_list_views.xml',
        'views/counting_list_menus.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'inventory_counting_lists/static/src/css/counting_lists.css',
            'inventory_counting_lists/static/src/xml/counting_lists.xml',
            'inventory_counting_lists/static/src/js/counting_lists.js',
        ],
    },
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}
