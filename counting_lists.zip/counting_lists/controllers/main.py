from odoo import http
from odoo.http import request
from datetime import date


class CountingListsController(http.Controller):

    @http.route('/counting_lists/get_lists', type='json', auth='user')
    def get_lists(self):
        """Get all active counting lists visible to this employee."""
        employee = request.env['hr.employee'].search(
            [('user_id', '=', request.env.uid)], limit=1
        )
        # Lists with no assignment (open to all) OR assigned to this employee
        all_lists = request.env['inventory.counting.list'].search([('active', '=', True)])
        lists = all_lists.filtered(
            lambda l: not l.assigned_employee_ids or
            (employee and employee in l.assigned_employee_ids)
        )
        result = []
        for lst in lists:
            # Check if there's a session today for this user
            today_session = request.env['inventory.counting.session'].search([
                ('counting_list_id', '=', lst.id),
                ('date', '=', date.today()),
                ('employee_id.user_id', '=', request.env.uid),
            ], limit=1)
            result.append({
                'id': lst.id,
                'name': lst.name,
                'department': lst.department_id.name if lst.department_id else '',
                'department_id': lst.department_id.id if lst.department_id else False,
                'location': lst.location_id.display_name if lst.location_id else 'All Locations',
                'product_count': lst.product_count,
                'notes': lst.notes or '',
                'color': lst.color,
                'today_session_id': today_session.id if today_session else False,
                'today_session_state': today_session.state if today_session else False,
                'today_progress': today_session.progress if today_session else 0,
                'today_counted': today_session.counted if today_session else 0,
                'schedule': lst.schedule,
                'assigned': bool(lst.assigned_employee_ids),
            })
        return result

    @http.route('/counting_lists/start_session', type='json', auth='user')
    def start_session(self, counting_list_id):
        """Start or resume a counting session for today."""
        employee = request.env['hr.employee'].search(
            [('user_id', '=', request.env.uid)], limit=1
        )
        # Check for existing session today
        existing = request.env['inventory.counting.session'].search([
            ('counting_list_id', '=', int(counting_list_id)),
            ('date', '=', date.today()),
            ('employee_id', '=', employee.id if employee else False),
        ], limit=1)

        if existing and existing.state == 'in_progress':
            return {'session_id': existing.id, 'resumed': True}

        if existing:
            return {
                'session_id': existing.id,
                'resumed': True,
                'state': existing.state
            }

        # Create new session with entries from list lines
        counting_list = request.env['inventory.counting.list'].browse(int(counting_list_id))
        session = request.env['inventory.counting.session'].create({
            'counting_list_id': counting_list.id,
            'date': date.today(),
            'employee_id': employee.id if employee else False,
            'state': 'in_progress',
        })

        # Create entries for each product line
        for line in counting_list.product_line_ids:
            location = line.location_id or counting_list.location_id
            # Find matching quant
            quant = request.env['stock.quant'].search([
                ('product_id', '=', line.product_id.id),
                ('location_id', '=', location.id if location else False),
            ], limit=1) if location else request.env['stock.quant'].browse()

            # Get expected qty from quant or 0
            expected_qty = quant.quantity if quant else 0.0

            request.env['inventory.counting.session.entry'].create({
                'session_id': session.id,
                'product_id': line.product_id.id,
                'location_id': location.id if location else False,
                'quant_id': quant.id if quant else False,
                'expected_quantity': expected_qty,
                'notes': line.notes or '',
            })

        return {'session_id': session.id, 'resumed': False}

    @http.route('/counting_lists/get_session', type='json', auth='user')
    def get_session(self, session_id):
        """Get session details with all entries."""
        session = request.env['inventory.counting.session'].browse(int(session_id))
        if not session.exists():
            return {'error': 'Session not found'}

        entries = []
        for e in session.entry_ids:
            product = e.product_id
            tmpl = product.product_tmpl_id
            base_name = tmpl.name or product.name or ''
            variant_name = product.product_template_attribute_value_ids.mapped('name')
            variant_str = ', '.join(variant_name) if variant_name else ''
            clean_name = f"{base_name} ({variant_str})" if variant_str else base_name

            entries.append({
                'id': e.id,
                'product_id': product.id,
                'product_name': clean_name,
                'product_default_code': product.default_code or '',
                'product_category': tmpl.categ_id.name if tmpl.categ_id else '',
                'product_uom': product.uom_id.name,
                'location_id': e.location_id.id if e.location_id else False,
                'location_name': e.location_id.display_name if e.location_id else '',
                'expected_quantity': e.expected_quantity,
                'inventory_quantity': e.inventory_quantity if e.inventory_quantity else None,
                'diff_quantity': e.diff_quantity,
                'notes': e.notes or '',
            })

        return {
            'id': session.id,
            'name': session.name,
            'list_name': session.counting_list_id.name,
            'department': session.counting_list_id.department_id.name if session.counting_list_id.department_id else '',
            'date': str(session.date),
            'state': session.state,
            'employee': session.employee_id.name if session.employee_id else '',
            'progress': session.progress,
            'counted': session.counted,
            'total': session.total,
            'notes': session.counting_list_id.notes or '',
            'entries': entries,
        }

    @http.route('/counting_lists/save_entry', type='json', auth='user')
    def save_entry(self, entry_id, quantity):
        """Save a counted quantity for one entry."""
        entry = request.env['inventory.counting.session.entry'].browse(int(entry_id))
        if not entry.exists():
            return {'success': False, 'error': 'Entry not found'}
        entry.inventory_quantity = float(quantity)
        return {
            'success': True,
            'inventory_quantity': entry.inventory_quantity,
            'diff_quantity': entry.diff_quantity,
        }

    @http.route('/counting_lists/submit_session', type='json', auth='user')
    def submit_session(self, session_id):
        """Submit session for manager review."""
        session = request.env['inventory.counting.session'].browse(int(session_id))
        if not session.exists():
            return {'success': False, 'error': 'Session not found'}
        session.action_submit()
        return {'success': True, 'state': session.state}

    @http.route('/counting_lists/get_pending_sessions', type='json', auth='user')
    def get_pending_sessions(self):
        """For managers: get all submitted sessions awaiting review."""
        sessions = request.env['inventory.counting.session'].search([
            ('state', '=', 'submitted')
        ], order='date desc')
        result = []
        for s in sessions:
            result.append({
                'id': s.id,
                'name': s.name,
                'list_name': s.counting_list_id.name,
                'department': s.counting_list_id.department_id.name if s.counting_list_id.department_id else '',
                'date': str(s.date),
                'employee': s.employee_id.name if s.employee_id else 'Unknown',
                'counted': s.counted,
                'total': s.total,
                'progress': s.progress,
            })
        return result

    @http.route('/counting_lists/approve_session', type='json', auth='user')
    def approve_session(self, session_id, notes=''):
        """Manager approves and applies counts."""
        session = request.env['inventory.counting.session'].browse(int(session_id))
        if not session.exists():
            return {'success': False, 'error': 'Session not found'}
        if notes:
            session.manager_notes = notes
        session.action_approve()
        return {'success': True}

    @http.route('/counting_lists/reject_session', type='json', auth='user')
    def reject_session(self, session_id, notes=''):
        """Manager rejects — sends back to staff."""
        session = request.env['inventory.counting.session'].browse(int(session_id))
        if not session.exists():
            return {'success': False, 'error': 'Session not found'}
        if notes:
            session.manager_notes = notes
        session.action_reject()
        return {'success': True}
