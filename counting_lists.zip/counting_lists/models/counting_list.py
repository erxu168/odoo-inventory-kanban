from odoo import models, fields, api
from datetime import date


class InventoryCountingList(models.Model):
    _name = 'inventory.counting.list'
    _description = 'Inventory Counting List'
    _order = 'name asc'

    name = fields.Char(string='List Name', required=True)
    department_id = fields.Many2one(
        'hr.department', string='Department', required=True,
        help='Department responsible for this counting list'
    )
    location_id = fields.Many2one(
        'stock.location', string='Default Location',
        domain=[('usage', '=', 'internal')],
        help='Default storage location for this list'
    )
    active = fields.Boolean(default=True)
    notes = fields.Text(string='Instructions for Staff')
    schedule = fields.Selection([
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('manual', 'Manual (no schedule)'),
    ], default='daily', string='Schedule', required=True)
    assigned_employee_ids = fields.Many2many(
        'hr.employee', string='Assigned Employees',
        help='Leave empty so any employee can pick it up, or assign to specific staff only'
    )
    product_line_ids = fields.One2many(
        'inventory.counting.list.line', 'counting_list_id',
        string='Products to Count'
    )
    product_count = fields.Integer(
        string='# Products', compute='_compute_product_count'
    )
    color = fields.Integer(string='Color', default=0)

    @api.depends('product_line_ids')
    def _compute_product_count(self):
        for rec in self:
            rec.product_count = len(rec.product_line_ids)


class InventoryCountingListLine(models.Model):
    _name = 'inventory.counting.list.line'
    _description = 'Counting List Product Line'
    _order = 'sequence asc, product_id asc'

    counting_list_id = fields.Many2one(
        'inventory.counting.list', string='Counting List',
        required=True, ondelete='cascade'
    )
    sequence = fields.Integer(default=10)
    product_id = fields.Many2one(
        'product.product', string='Product', required=True,
        domain=[('type', 'in', ['product', 'consu'])]
    )
    location_id = fields.Many2one(
        'stock.location', string='Location Override',
        domain=[('usage', '=', 'internal')],
        help='Leave empty to use the list default location'
    )
    notes = fields.Char(string='Note', help='Short note shown to staff')

    def _get_effective_location(self):
        return self.location_id or self.counting_list_id.location_id


class InventoryCountingSession(models.Model):
    """Tracks a counting session — one per staff member per list per day."""
    _name = 'inventory.counting.session'
    _description = 'Counting Session'
    _order = 'date desc, id desc'

    name = fields.Char(string='Reference', compute='_compute_name', store=True)
    counting_list_id = fields.Many2one(
        'inventory.counting.list', string='Counting List', required=True
    )
    date = fields.Date(string='Date', default=fields.Date.today, required=True)
    employee_id = fields.Many2one(
        'hr.employee', string='Employee',
        default=lambda self: self.env['hr.employee'].search(
            [('user_id', '=', self.env.uid)], limit=1
        )
    )
    state = fields.Selection([
        ('in_progress', 'In Progress'),
        ('submitted', 'Submitted — Awaiting Review'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ], default='in_progress', string='Status')
    entry_ids = fields.One2many(
        'inventory.counting.session.entry', 'session_id',
        string='Count Entries'
    )
    counted = fields.Integer(compute='_compute_progress', string='Counted')
    total = fields.Integer(compute='_compute_progress', string='Total')
    progress = fields.Float(compute='_compute_progress', string='Progress %')
    manager_notes = fields.Text(string='Manager Notes')

    @api.depends('counting_list_id', 'date', 'employee_id')
    def _compute_name(self):
        for rec in self:
            parts = []
            if rec.counting_list_id:
                parts.append(rec.counting_list_id.name)
            if rec.date:
                parts.append(str(rec.date))
            if rec.employee_id:
                parts.append(rec.employee_id.name)
            rec.name = ' / '.join(parts) if parts else 'New Session'

    @api.depends('entry_ids.inventory_quantity')
    def _compute_progress(self):
        for rec in self:
            total = len(rec.entry_ids)
            counted = len(rec.entry_ids.filtered(
                lambda e: e.inventory_quantity is not False and e.inventory_quantity is not None
            ))
            rec.total = total
            rec.counted = counted
            rec.progress = (counted / total * 100) if total else 0

    def action_submit(self):
        self.state = 'submitted'

    def action_approve(self):
        """Apply counts to inventory."""
        for entry in self.entry_ids:
            if entry.inventory_quantity is not False and entry.quant_id:
                entry.quant_id.inventory_quantity = entry.inventory_quantity
        self.state = 'approved'

    def action_reject(self):
        self.state = 'rejected'

    def action_reopen(self):
        self.state = 'in_progress'


class InventoryCountingSessionEntry(models.Model):
    _name = 'inventory.counting.session.entry'
    _description = 'Counting Session Entry'

    session_id = fields.Many2one(
        'inventory.counting.session', required=True, ondelete='cascade'
    )
    product_id = fields.Many2one('product.product', string='Product', required=True)
    location_id = fields.Many2one('stock.location', string='Location')
    quant_id = fields.Many2one('stock.quant', string='Stock Quant')
    expected_quantity = fields.Float(string='Expected Qty', digits=(16, 2))
    inventory_quantity = fields.Float(string='Counted Qty', digits=(16, 2))
    diff_quantity = fields.Float(
        string='Difference', compute='_compute_diff', store=True
    )
    notes = fields.Char(string='Note')
    product_name = fields.Char(related='product_id.name', string='Product Name')
    product_default_code = fields.Char(
        related='product_id.default_code', string='Ref'
    )
    product_uom = fields.Char(
        related='product_id.uom_id.name', string='Unit'
    )
    location_name = fields.Char(
        related='location_id.display_name', string='Location Name'
    )
    product_category = fields.Char(
        related='product_id.categ_id.name', string='Category'
    )

    @api.depends('inventory_quantity', 'expected_quantity')
    def _compute_diff(self):
        for rec in self:
            if rec.inventory_quantity is not False:
                rec.diff_quantity = rec.inventory_quantity - rec.expected_quantity
            else:
                rec.diff_quantity = 0
