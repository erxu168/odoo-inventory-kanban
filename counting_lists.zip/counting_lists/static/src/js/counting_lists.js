/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, useState, onMounted } from "@odoo/owl";

async function jsonRpc(route, params = {}) {
    const response = await fetch(route, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", method: "call", params }),
    });
    const data = await response.json();
    if (data.error) throw new Error(data.error.data?.message || data.error.message || "RPC Error");
    return data.result;
}

// ─── Colour map for department cards ───────────────────────────────────────
const DEPT_COLORS = {
    0: '#1a73e8', 1: '#e53935', 2: '#e67c00', 3: '#0b8043',
    4: '#8e24aa', 5: '#00838f', 6: '#3949ab', 7: '#d81b60',
    8: '#6d4c41', 9: '#546e7a', 10: '#f4511e', 11: '#0288d1',
};

class CountingListsApp extends Component {
    static template = "inventory_counting_lists.App";

    setup() {
        this.state = useState({
            // screens: 'home' | 'counting' | 'review'
            screen: 'home',
            lists: [],
            loading: false,
            session: null,
            numpad: { open: false, entry: null, inputStr: "" },
            toast: null,
        });
        this._toastTimer = null;
        onMounted(() => this.loadLists());
    }

    // ── Data ─────────────────────────────────────────────────────────────────

    async loadLists() {
        this.state.loading = true;
        try {
            this.state.lists = await jsonRpc('/counting_lists/get_lists');
        } catch (e) {
            this.showToast("Failed to load counting lists", "error");
        }
        this.state.loading = false;
    }

    async openList(lst) {
        this.state.loading = true;
        try {
            const res = await jsonRpc('/counting_lists/start_session', {
                counting_list_id: lst.id,
            });
            if (res.error) { this.showToast(res.error, 'error'); return; }

            if (res.state && res.state !== 'in_progress') {
                this.showToast(`This list was already ${res.state}`, 'warning');
            }

            const session = await jsonRpc('/counting_lists/get_session', {
                session_id: res.session_id,
            });
            this.state.session = session;
            this.state.screen = 'counting';
        } catch (e) {
            this.showToast("Failed to open list", "error");
        }
        this.state.loading = false;
    }

    async submitSession() {
        if (!this.state.session) return;
        this.state.loading = true;
        try {
            await jsonRpc('/counting_lists/submit_session', {
                session_id: this.state.session.id,
            });
            this.showToast("Submitted for manager review ✓", "success");
            this.state.screen = 'home';
            await this.loadLists();
        } catch (e) {
            this.showToast("Failed to submit", "error");
        }
        this.state.loading = false;
    }

    goHome() {
        this.state.screen = 'home';
        this.state.session = null;
        this.loadLists();
    }

    // ── Numpad ────────────────────────────────────────────────────────────────

    openNumpad(entry) {
        this.state.numpad.entry = entry;
        const v = entry.inventory_quantity;
        this.state.numpad.inputStr = v !== null && v !== undefined
            ? String(parseFloat(v)).replace(/\.?0+$/, '') : "";
        this.state.numpad.open = true;
    }

    closeNumpad() {
        this.state.numpad.open = false;
        this.state.numpad.entry = null;
        this.state.numpad.inputStr = "";
    }

    numpadKey(k) {
        if (k === '.' && this.state.numpad.inputStr.includes('.')) return;
        if (this.state.numpad.inputStr.length >= 8) return;
        if (k === '.' && !this.state.numpad.inputStr) this.state.numpad.inputStr = '0';
        if (k !== '.' && this.state.numpad.inputStr === '0') this.state.numpad.inputStr = '';
        this.state.numpad.inputStr += k;
    }

    numpadDelete() { this.state.numpad.inputStr = this.state.numpad.inputStr.slice(0, -1); }
    numpadClear()  { this.state.numpad.inputStr = ""; }

    numpadSetMatch() {
        const qty = this.state.numpad.entry?.expected_quantity || 0;
        this.state.numpad.inputStr = String(parseFloat(qty)).replace(/\.?0+$/, '') || "0";
    }

    async numpadConfirm() {
        if (!this.state.numpad.inputStr) return;
        const qty = parseFloat(this.state.numpad.inputStr);
        const entry = this.state.numpad.entry;
        try {
            const res = await jsonRpc('/counting_lists/save_entry', {
                entry_id: entry.id,
                quantity: qty,
            });
            if (res.success) {
                entry.inventory_quantity = res.inventory_quantity;
                entry.diff_quantity = res.diff_quantity;
                const diff = res.diff_quantity;
                const msg = Math.abs(diff) < 0.005
                    ? entry.product_name + " — ✓ Match"
                    : entry.product_name + (diff > 0 ? ` +${diff.toFixed(2)}` : ` ${diff.toFixed(2)}`);
                this.showToast(msg, Math.abs(diff) < 0.005 ? "success" : "warning");
                this.closeNumpad();
                // Update session progress
                this._refreshProgress();
            }
        } catch (e) {
            this.showToast("Failed to save", "error");
        }
    }

    numpadSkip() {
        this.showToast("Skipped", "");
        this.closeNumpad();
    }

    _refreshProgress() {
        if (!this.state.session) return;
        const entries = this.state.session.entries;
        const total = entries.length;
        const counted = entries.filter(e => e.inventory_quantity !== null && e.inventory_quantity !== undefined).length;
        this.state.session.counted = counted;
        this.state.session.total = total;
        this.state.session.progress = total ? (counted / total * 100) : 0;
    }

    // ── Computed ──────────────────────────────────────────────────────────────

    get numpadDiff() {
        const np = this.state.numpad;
        if (!np.inputStr || !np.entry) return null;
        return parseFloat(np.inputStr) - (np.entry.expected_quantity || 0);
    }

    get numpadDiffFormatted() {
        const d = this.numpadDiff;
        if (d === null) return "—";
        if (Math.abs(d) < 0.005) return "±0";
        return d > 0 ? `+${d.toFixed(2)}` : d.toFixed(2);
    }

    get numpadDiffClass() {
        const d = this.numpadDiff;
        if (d === null) return "none";
        if (Math.abs(d) < 0.005) return "zero";
        return d > 0 ? "pos" : "neg";
    }

    getDeptColor(color) {
        return DEPT_COLORS[color % 12] || '#1a73e8';
    }

    getStateLabel(state) {
        return {
            'in_progress': 'In Progress',
            'submitted': '⏳ Awaiting Review',
            'approved': '✓ Approved',
            'rejected': '✗ Rejected',
        }[state] || state;
    }

    getScheduleLabel(schedule) {
        return { 'daily': 'Daily', 'weekly': 'Weekly', 'monthly': 'Monthly', 'manual': 'On Demand' }[schedule] || schedule;
    }

    getStateClass(state) {
        return {
            'in_progress': 'cls-progress',
            'submitted': 'cls-submitted',
            'approved': 'cls-approved',
            'rejected': 'cls-rejected',
        }[state] || '';
    }

    formatQty(qty) {
        if (qty === null || qty === undefined) return "0";
        const n = parseFloat(qty);
        return isNaN(n) ? "0" : (Number.isInteger(n) ? n.toString() : n.toFixed(2).replace(/\.?0+$/, ''));
    }

    // ── Toast ─────────────────────────────────────────────────────────────────

    showToast(message, type = "") {
        clearTimeout(this._toastTimer);
        this.state.toast = { message, type };
        this._toastTimer = setTimeout(() => { this.state.toast = null; }, 3000);
    }
}

registry.category("actions").add("inventory_counting_lists_app", CountingListsApp);
