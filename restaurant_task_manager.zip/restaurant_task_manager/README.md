# Restaurant Task Manager for Odoo 19

Shift-linked task management for multi-location restaurant operations. Assign task templates to planning roles, auto-generate individual checklists per employee per shift, enforce completion at clock-out, and escalate overdue tasks through a configurable chain.

## Features

### Task Templates
- Reusable task lists assigned to planning roles (Kitchen Opener, FOH Closer, etc.)
- 5 completion types: checkbox, photo (camera), numeric value, text note, digital signature
- Nested sub-task checklists with all-or-nothing validation
- Optional deadlines relative to shift start (e.g., "30 min after shift begins")
- PDF instruction attachments per task
- Pre-deadline reminders configurable per task (5, 10, 15 min before)

### Shift Integration
- Auto-generates task lists when planning shifts are published
- Matches templates to shifts by planning role and work location
- Each employee receives their own individual task list copy
- Task completion visible on the planning shift form

### Clock-Out Enforcement
- Configurable per template: **Block** (hard-stop) or **Warn** (log and allow)
- Block policy prevents attendance check-out until all mandatory tasks are done
- Task completion percentage shown on attendance records

### Shift Handoff
- Incomplete tasks auto-carry to the next shift's person in the same role
- Handed-off tasks are prefixed with `[HANDOFF]` for visibility
- Partial checklist progress is preserved during handoff

### Multi-Level Escalation
- Configurable escalation chain: employee → shift lead → area manager
- Timed intervals (e.g., Level 1 at 0 min, Level 2 at +15 min, Level 3 at +30 min)
- Notifications via Odoo activity, email, and SMS
- Tracks which escalation levels have fired per task

### Ad-Hoc Quick Tasks
- Managers create one-off tasks for specific employees during live shifts
- Supports checkbox, photo, and text completion types
- Separate from template-based tasks — no template required

### Scoring & Comparison
- Simple scoring: completed / total = %
- Staff sees their own score + anonymous team average at same location
- Manager dashboard with:
  - Today's real-time overview
  - Completion by employee (bar chart)
  - Completion by location (bar chart)
  - Weekly and monthly trend analysis (line/pivot)
  - Cross-location comparison
  - Overdue tasks and handed-off tasks views
  - Staff comments review

### 3-Tier Access Control
| Role | Capabilities |
|------|-------------|
| **Owner/Admin** | Full access across all locations, create/delete templates, configure escalation rules, system settings |
| **Manager** | Manage tasks at their location(s), create quick tasks, access dashboard, view all staff lists |
| **Staff** | View and complete own assigned tasks, leave comments, see own score + team average |

Multi-location data isolation: staff only see their own tasks; managers see tasks across their scope.

## Requirements

- Odoo 19 Community or Enterprise
- Required modules: `hr`, `hr_attendance`, `planning`, `mail`, `sms`

## Installation

1. Copy the `restaurant_task_manager` folder to your Odoo addons path
2. Restart the Odoo service
3. Go to **Apps** → Update Apps List
4. Search for "Restaurant Task Manager" and install
5. Demo data is loaded automatically if Odoo is running in demo mode

## Configuration

### 1. Create Task Templates
Go to **Restaurant Tasks → Configuration → Task Templates**

1. Name your template (e.g., "Kitchen Opening Tasks")
2. Assign planning roles — shifts with these roles will auto-receive this task list
3. Optionally restrict to a specific work location
4. Set the checkout policy:
   - **Show Warning**: allows checkout with incomplete tasks (logs a warning)
   - **Block Checkout**: prevents checkout until all tasks are complete
5. Add tasks with:
   - Completion type (checkbox, photo, numeric, text, signature)
   - Optional deadline (minutes after shift start)
   - Optional pre-deadline reminder (minutes before deadline)
   - Sub-task checklist items
   - PDF instruction attachment

### 2. Set Up Escalation Rules
Go to **Restaurant Tasks → Configuration → Escalation Rules**

Add escalation levels in order:

| Level | Delay | Recipient | Channels |
|-------|-------|-----------|----------|
| 1 | 0 min | Assigned Employee | Email |
| 2 | 15 min | Department Manager | Email + SMS |
| 3 | 30 min | Employee's Manager | Email + SMS |

### 3. Assign Planning Roles
Ensure your employees have planning roles set in **Planning → Configuration → Roles**. When shifts are published, task lists auto-generate for matching roles.

### 4. Set Up Work Locations
Create work locations in **Employees → Configuration → Work Locations** for multi-location isolation.

## Usage

### For Staff
1. Go to **Restaurant Tasks → My Tasks** to see assigned task lists
2. Open a task list and work through each task:
   - Check sub-task items as you go
   - Provide required proof (photo, numeric value, text, signature)
   - Click "✓ Done" to complete each task
3. Quick tasks assigned by managers appear under **My Quick Tasks**
4. Leave comments on tasks if you have issues (visible to managers)

### For Managers
1. **Today's Overview** shows real-time status of all active task lists
2. **Quick Tasks** lets you assign ad-hoc tasks to specific employees
3. **Staff Comments** surfaces any issues employees reported
4. **Overdue Tasks** shows all tasks past their deadline
5. **Handed Off Tasks** shows tasks carried over between shifts
6. Dashboard views provide completion analysis by employee, location, and over time

### For Admins
1. Configure templates, escalation rules, and work locations
2. All dashboard and reporting views are available across all locations
3. Export any list/pivot view to Excel/PDF using Odoo's native export

## Automated Processes

| Cron Job | Interval | Purpose |
|----------|----------|---------|
| Pre-Deadline Reminders | 5 min | Sends reminders X minutes before task deadline |
| Overdue Check | 10 min | Creates activities for overdue tasks |
| Escalation Chain | 5 min | Triggers multi-level notifications for overdue tasks |
| Shift Handoff | 10 min | Carries incomplete tasks to next shift |
| Warning Emails | 15 min | Emails employees who clocked out with incomplete tasks |
| Auto-Generate | 1 hour | Creates task lists for published shifts in the next 7 days |

## Demo Data

When installed with demo data enabled, the module creates:

- 2 work locations (Downtown Branch, Waterfront Branch)
- 5 planning roles (Kitchen Opener/Closer, FOH Opener/Closer, Shift Manager)
- 4 task list templates with realistic restaurant tasks:
  - **Kitchen Opening**: walk-in/freezer temperature checks, prep station setup, equipment safety
  - **Kitchen Closing**: deep clean with photo proof, end-of-day temperature log, manager sign-off
  - **FOH Opening**: dining setup, restroom inspection, POS system check
  - **FOH Closing**: cash out, dining area cleanup
- 3-level escalation chain (employee → department manager → parent manager)
- Sub-task checklists on key tasks

## Technical Details

### Models

| Model | Description |
|-------|-------------|
| `restaurant.task.list.template` | Reusable task list template with role binding |
| `restaurant.task.template` | Individual task definition within a template |
| `restaurant.subtask.template` | Checklist item template |
| `restaurant.task.list` | Concrete task list linked to a planning shift |
| `restaurant.task.item` | Individual task within a shift task list |
| `restaurant.task.subtask` | Checklist item within a task |
| `restaurant.escalation.rule` | Escalation chain level configuration |
| `restaurant.quick.task` | Ad-hoc task created during live shifts |

### Inherited Models
- `hr.attendance`: task completion score, clock-out enforcement
- `hr.employee` / `hr.employee.public`: average score, team average
- `planning.slot`: task list count, completion score, auto-generation on publish

## Licence

LGPL-3
